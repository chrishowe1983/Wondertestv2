
  # Wonderlist2209

  This is a code bundle for Wonderlist2209. The original project is available at https://www.figma.com/design/zWiPwc07qSw71aoEBWg4FL/Wonderlist2209.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  